"""
Amazon Bedrock Multi-Tenant Cost Tracking - Resource Groups API Version

This version uses Resource Groups API instead of S3 for dynamic ARN resolution
"""

import json
import boto3
import time
import os
from datetime import datetime
from typing import Dict, Any, Optional
from botocore.config import Config

# Global AWS clients (reuse across invocations)
bedrock_runtime = boto3.client('bedrock-runtime', config=Config(
    retries={'max_attempts': 3}
))
bedrock = boto3.client('bedrock', config=Config(
    retries={'max_attempts': 3}
))
dynamodb = boto3.resource('dynamodb')
resource_groups_tagging_api = boto3.client('resourcegroupstaggingapi', config=Config(
    retries={'max_attempts': 3}
))
cloudwatch = boto3.client('cloudwatch')
sns = boto3.client('sns')
events = boto3.client('events')

# Cache configurations
ARN_CACHE: Dict[str, Any] = {}  # tenant_id#app_id -> {arn, expiry}
TENANT_CONFIG_CACHE: Dict[str, Any] = {}
MODEL_PRICING_CACHE: Dict[str, Any] = {}

# Cache TTLs
ARN_CACHE_TTL = 3600  # 1 hour for ARN cache
CONFIG_CACHE_TTL = 300  # 5 minutes for tenant config
PRICING_CACHE_TTL = 86400  # 24 hours for pricing


def should_refresh_cache(expiry: float) -> bool:
    """Check if cache entry has expired"""
    return time.time() > expiry


def get_from_cache(cache: Dict, key: str, ttl: float) -> Optional[Any]:
    """Get value from cache if not expired"""
    if key in cache:
        entry = cache[key]
        if time.time() < entry['expiry']:
            return entry['value']
    return None


def put_to_cache(cache: Dict, key: str, value: Any, ttl: int):
    """Store value in cache with TTL"""
    cache[key] = {
        'value': value,
        'expiry': time.time() + ttl
    }


def get_tenant_config(tenant_id: str) -> Dict[str, Any]:
    """
    Get tenant configuration from DynamoDB

    Cache: 5 minutes TTL
    """
    cached = get_from_cache(TENANT_CONFIG_CACHE, tenant_id, CONFIG_CACHE_TTL)
    if cached:
        return cached

    table = dynamodb.Table('bedrock-cost-tracking-production-tenant-configs')
    response = table.get_item(
        Key={'tenantId': tenant_id},
        ConsistentRead=False
    )

    if 'Item' not in response:
        raise ValueError(f"Tenant {tenant_id} not found")

    config = response['Item']
    put_to_cache(TENANT_CONFIG_CACHE, tenant_id, config, CONFIG_CACHE_TTL)
    return config


def get_inference_profile_arn(tenant_id: str, application_id: str) -> str:
    """
    Get inference profile ARN using Resource Groups API

    Steps:
      1. Check ARN cache
      2. Call Resource Groups GetResources API
      3. Cache result (1 hour TTL)
      4. Return ARN

    Args:
        tenant_id: Tenant identifier
        application_id: Application identifier

    Returns:
        Inference profile ARN
    """
    cache_key = f"{tenant_id}#{application_id}"

    # Check cache
    cached = get_from_cache(ARN_CACHE, cache_key, time.time())
    if cached:
        return cached

    # Call Resource Groups API
    try:
        response = resource_groups_tagging_api.get_resources(
            ResourceTypeFilters=['bedrock'],
            TagFilters=[
                {'Key': 'TenantID', 'Values': [tenant_id]},
                {'Key': 'ApplicationID', 'Values': [application_id]}
            ]
        )

        if not response.get('ResourceTagMappingList'):
            raise ValueError(f"No inference profile found for tenant {tenant_id}, app {application_id}")

        arn = response['ResourceTagMappingList'][0]['ResourceARN']

        # Cache result
        put_to_cache(ARN_CACHE, cache_key, arn, ARN_CACHE_TTL)

        return arn

    except Exception as e:
        logger.error(f"Resource Groups API failed: {e}")
        raise


def get_model_pricing(region: str, model_id: str) -> Dict[str, float]:
    """Get model pricing from DynamoDB"""
    cache_key = f"{region}#{model_id}"

    cached = get_from_cache(MODEL_PRICING_CACHE, cache_key, time.time())
    if cached:
        return cached

    table = dynamodb.Table('bedrock-cost-tracking-production-model-pricing')
    response = table.get_item(
        Key={'region': region, 'modelId': model_id}
    )

    if 'Item' not in response:
        raise ValueError(f"Pricing not found for {region}/{model_id}")

    pricing = response['Item']
    put_to_cache(MODEL_PRICING_CACHE, cache_key, pricing, PRICING_CACHE_TTL)

    return pricing


def check_budget(tenant_id: str, estimated_cost: float) -> bool:
    """
    Check budget before calling Bedrock

    Args:
        tenant_id: Tenant identifier
        estimated_cost: Estimated cost for the call

    Returns:
        True if budget is sufficient, False otherwise
    """
    try:
        table = dynamodb.Table('bedrock-cost-tracking-production-tenant-budgets')
        response = table.get_item(
            Key={'tenantId': tenant_id, 'modelId': 'ALL'},
            ProjectionExpression='balance, totalBudget, alertThreshold'
        )

        if 'Item' not in response:
            # No budget configured, allow by default
            logger.info(f"No budget found for tenant {tenant_id}, allowing call")
            return True

        item = response['Item']
        balance = float(item['balance'])

        # Check if sufficient balance
        if balance >= estimated_cost:
            # Check for low budget warning
            alert_threshold = float(item.get('alertThreshold', 0.8))
            utilization = balance / float(item['totalBudget'])

            if utilization < (1 - alert_threshold):
                logger.warning(f"Budget low for {tenant_id}: {utilization:.1%} remaining")

            return True
        else:
            logger.warning(f"Insufficient budget for {tenant_id}: ${balance:.4f} < ${estimated_cost:.4f}")
            return False

    except Exception as e:
        logger.error(f"Budget check failed for {tenant_id}: {e}")
        return True  # Degrade gracefully


def update_budget(tenant_id: str, model_id: str, input_tokens: int, output_tokens: int, cost: float):
    """
    Update budget asynchronously with model-specific breakdown

    Note: In this update_budget function in the MAIN lambda, we only maintain the basic
    balance update for backward compatibility. The detailed model breakdown is handled
    in the cost management function.
    """
    try:
        table = dynamodb.Table('TenantBudgets')
        table.update_item(
            Key={'tenantId': tenant_id, 'modelId': 'ALL'},
            UpdateExpression="""
                SET balance = balance - :cost,
                    lastUpdated = :timestamp
            """,
            ExpressionAttributeValues={
                ':cost': cost,
                ':timestamp': time.time_ns()
            },
            ConditionExpression='balance >= :cost'
        )
        logger.info(f"Budget updated for {tenant_id}: -${cost:.4f}")

    except Exception as e:
        logger.error(f"Budget update failed for {tenant_id}: {e}")


def log_emf_metrics(**metrics):
    """Log metrics using Embedded Metric Format"""
    emf_entry = {
        "_aws": {
            "Timestamp": int(time.time() * 1000),
            "CloudWatchMetrics": [
                {
                    "Namespace": "BedrockInvocationTracing",
                    "Dimensions": [
                        ["TenantID"],
                        ["TenantID", "ApplicationID"],
                        ["TenantID", "ApplicationID", "ModelID"]
                    ],
                    "Metrics": [
                        {"Name": "InputTokens", "Unit": "Count"},
                        {"Name": "OutputTokens", "Unit": "Count"},
                        {"Name": "InvocationCost", "Unit": "None"},
                        {"Name": "InvocationCount", "Unit": "Count"}
                    ]
                }
            ]
        },
        "TenantID": metrics['tenant_id'],
        "ApplicationID": metrics['application_id'],
        "ModelID": metrics['model_id'],
        "InputTokens": metrics['input_tokens'],
        "OutputTokens": metrics['output_tokens'],
        "InvocationCost": round(metrics['cost'], 6),
        "InvocationCount": 1
    }
    print(json.dumps(emf_entry))


def log_high_cost_alert(tenant_id: str, actual_cost: float, threshold: float = 0.001, application_id: str = None):
    """
    Log alert for high-cost invocation (e.g., cost > threshold)

    This function records both EMF metrics for CloudWatch alarm triggering
    and a detailed debug log for troubleshooting.

    Threshold is configurable for different use cases:
    - Production: $10.0 (default for production environment)
    - Demo: $0.001 (triggers on every call for demonstration)

    Trigger: CloudWatch Alarm → SNS → Notify administrators

    Args:
        tenant_id: Tenant identifier
        actual_cost: Actual cost of the invocation
        threshold: Cost threshold in USD (default: $0.001 for demo use)
        application_id: Application identifier (optional)
    """
    if actual_cost <= threshold:
        return  # Cost is within normal range, no alert needed

    # EMF metric for CloudWatch alarm
    alert_entry = {
        "_aws": {
            "Timestamp": int(time.time() * 1000),
            "CloudWatchMetrics": [
                {
                    "Namespace": "BedrockInvocationTracing",
                    "Dimensions": [
                        ["TenantID"]  # Per-tenant dimension
                    ],
                    "Metrics": [
                        {
                            "Name": "HighCostInvocation",
                            "Unit": "Count"
                        }
                    ]
                }
            ]
        },
        "TenantID": tenant_id,
        "HighCostInvocation": 1,  # Alert count
        "AlertThreshold": threshold,
        "ActualCost": round(actual_cost, 6)
    }

    # Debug log for investigation
    debug_info = {
        "level": "ALERT",
        "message": "High cost invocation detected",
        "tenantId": tenant_id,
        "cost": actual_cost,
        "threshold": threshold,
        "timestamp": int(time.time()),
        "applicationId": application_id
    }
    print(json.dumps(debug_info))

    # Print EMF metric
    print(json.dumps(alert_entry))


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda handler - main entry point"""
    try:
        # 1. Parse request
        headers = event.get('headers', {})
        tenant_id = headers.get('x-tenant-id') or \
                    event.get('queryStringParameters', {}).get('tenantId') or \
                    json.loads(event.get('body', '{}')).get('tenantId')

        if not tenant_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Tenant ID is required'})
            }

        # 2. Parse request body
        body = json.loads(event.get('body', '{}'))
        application_id = body.get('applicationId')
        prompt = body.get('prompt')
        requested_model = body.get('model')

        # 3. Get tenant config
        config = get_tenant_config(tenant_id)

        # 4. Validate requested model
        if requested_model:
            if requested_model not in config.get('allowedModels', []):
                return {
                    'statusCode': 403,
                    'body': json.dumps({'error': 'Model not allowed for tenant'})
                }
            model_id = requested_model
        else:
            model_id = config['defaultModelId']

        # 5. Get inference profile ARN
        inference_profile_arn = get_inference_profile_arn(tenant_id, application_id)

        # 6. Estimate cost
        estimated_input_tokens = len(prompt.split()) * 1.3
        estimated_output_tokens = estimated_input_tokens * 0.8
        estimated_cost = estimate_cost(model_id, estimated_input_tokens, estimated_output_tokens)

        # 7. Check budget
        if not check_budget(tenant_id, estimated_cost):
            return {
                'statusCode': 402,
                'body': json.dumps({
                    'error': 'Budget exceeded',
                    'tenantId': tenant_id,
                    'estimatedCost': estimated_cost
                })
            }

        # 8. Call Bedrock
        response = bedrock_runtime.converse(
            modelId=inference_profile_arn,
            messages=[{
                'role': 'user',
                'content': [{'text': prompt}]
            }],
            inferenceConfig={
                'maxTokens': body.get('maxTokens', 1000),
                'temperature': body.get('temperature', 0.7)
            }
        )

        # 9. Extract usage
        result = response['output']['message']['content'][0]['text']
        input_tokens = response['usage']['inputTokens']
        output_tokens = response['usage']['outputTokens']

        # 10. Calculate actual cost
        actual_cost = calculate_cost(model_id, input_tokens, output_tokens)

        # 11. Update budget (async)
        update_budget(tenant_id, actual_cost)

        # 12. Log metrics
        log_emf_metrics(
            tenant_id=tenant_id,
            application_id=application_id,
            model_id=model_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost=actual_cost
        )

        # 13. Publish event to EventBridge for async cost management processing
        publish_cost_event(
            event_bus_name=os.environ.get('EVENT_BUS_NAME', 'default'),
            tenant_id=tenant_id,
            application_id=application_id,
            model_id=model_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            actual_cost=actual_cost
        )

        # 14. Check and log high-cost alert (threshold: $0.001 for demo)
        # 注意: 生产环境建议设置为更高阈值（如 $10.0）
        log_high_cost_alert(
            tenant_id=tenant_id,
            actual_cost=actual_cost,
            threshold=0.001,  # $0.001 threshold for demonstrations
            application_id=application_id
        )

        # 15. Return response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'X-Tenant-Id': tenant_id,
                'X-Cost': str(actual_cost)
            },
            'body': json.dumps({
                'response': result,
                'usage': {
                    'inputTokens': input_tokens,
                    'outputTokens': output_tokens,
                    'cost': actual_cost
                }
            })
        }

    except Exception as e:
        logger.error(f"Error in lambda_handler: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


# Helper functions
def estimate_cost(model_id: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost based on model and token count"""
    pricing = get_model_pricing('us-east-1', model_id)
    # Convert Decimal to float for calculations
    input_cost_value = float(pricing['inputCost'])
    output_cost_value = float(pricing['outputCost'])
    input_cost = input_cost_value * (input_tokens / 1000000)
    output_cost = output_cost_value * (output_tokens / 1000000)
    return input_cost + output_cost


def calculate_cost(model_id: str, input_tokens: int, output_tokens: int) -> float:
    """Calculate actual cost"""
    return estimate_cost(model_id, input_tokens, output_tokens)


def publish_cost_event(event_bus_name: str, tenant_id: str, application_id: str,
                       model_id: str, input_tokens: int, output_tokens: int, actual_cost: float):
    """
    Publish cost tracking event to EventBridge

    This allows the cost management function to process metrics and budget updates asynchronously,
    ensuring the main function remains fast and responsive.

    Args:
        event_bus_name: EventBridge event bus name
        tenant_id: Tenant identifier
        application_id: Application identifier
        model_id: Model ID used
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        actual_cost: Calculated cost
    """
    try:
        # Check if cost tracking is enabled
        enable_cost_tracking = os.environ.get('ENABLE_COST_TRACKING', 'true').lower() == 'true'
        if not enable_cost_tracking:
            logger.info("Cost tracking disabled, skipping event publication")
            return

        event_detail = {
            'tenantId': tenant_id,
            'applicationId': application_id,
            'modelId': model_id,
            'inputTokens': input_tokens,
            'outputTokens': output_tokens,
            'cost': actual_cost,
            'timestamp': int(time.time())
        }

        response = events.put_events(
            Entries=[{
                'Source': 'bedrock.invocation',
                'DetailType': 'BedrockInvocationCost',
                'Detail': json.dumps(event_detail),
                'EventBusName': event_bus_name
            }]
        )

        if response.get('FailedEntryCount', 0) > 0:
            logger.error(f"Failed to publish event: {response}")
        else:
            logger.info(f"Published cost event for tenant {tenant_id}: ${actual_cost:.4f}")

    except Exception as e:
        logger.error(f"Error publishing cost event: {e}")
        # Non-critical - don't fail the main request



def get_tags_from_inference_profile(arn: str) -> Dict[str, str]:
    """Get tags from inference profile"""
    try:
        response = bedrock.list_tags_for_resource(resourceARN=arn)
        return {tag['key']: tag['value'] for tag in response['tags']}
    except Exception:
        return {}


# Logger
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


# Note on Resource Groups API vs S3 approach:
#
# This implementation uses Resource Groups API which provides:
# - Real-time ARN lookup (no configuration files)
# - Automatic reflection of changes (no TTL delay)
# - Native AWS service integration
# - More maintainable than S3-based approach
#
# Benefits over S3 approach:
# 1. No need to maintain config.json in S3
# 2. Changes to inference profiles are immediately available
# 3. No manual cache refresh required
# 4. Uses official AWS APIs for resource discovery
# 5. Better security (no S3 bucket permissions needed)
#
# Trade-offs:
# - API call latency (~50-100ms first time)
# - API call costs (negligible at scale)
# - Requires resource-groups:GetResources permission
